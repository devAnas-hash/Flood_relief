/*
Flood Relief Management System - Single-file C++ with SQLite CRUD

Features added in this version:
 - Full CRUD (Create, Read, Update, Delete) functions for Users, Resources,
   Disaster Zones, Volunteers, and Requests using SQLite prepared statements.
 - SQL schema initialization executed at program start (embedded SQL schema and
   also written out as `database.sql`).
 - Secure prepared statements usage (sqlite3_prepare_v2 / sqlite3_bind_*)
 - Helper functions to execute queries and fetch results
 - Windows 10 & Linux terminal compile/run instructions included at the bottom

Compile (Linux / macOS):
    g++ main.cpp -lsqlite3 -o flood_app

Compile (MSYS2 / MinGW on Windows):
    g++ main.cpp -lsqlite3 -o flood_app.exe

Run:
    ./flood_app      (or flood_app.exe on Windows)

Note: This single-file program both initializes the sqlite database file
(`flood.db`) and exposes a console menu similar to the original design.
*/

#include <bits/stdc++.h>
#include <sqlite3.h>
using namespace std;

// ----------------- ENUMS & HELPERS -----------------
enum class Role { ADMIN = 0, COORDINATOR = 1, VOLUNTEER = 2 };
enum class ResourceType { FOOD = 0, WATER = 1, SHELTER = 2, MEDICAL = 3, OTHER = 4 };

static const char* DB_FILENAME = "flood.db";

string role_to_string(Role r){
    switch(r){
        case Role::ADMIN: return "ADMIN";
        case Role::COORDINATOR: return "COORDINATOR";
        case Role::VOLUNTEER: return "VOLUNTEER";
    }
    return "UNKNOWN";
}

string res_to_string(ResourceType t){
    switch(t){
        case ResourceType::FOOD: return "FOOD";
        case ResourceType::WATER: return "WATER";
        case ResourceType::SHELTER: return "SHELTER";
        case ResourceType::MEDICAL: return "MEDICAL";
        case ResourceType::OTHER: return "OTHER";
    }
    return "UNKNOWN";
}


int getIntInRange(int minv, int maxv){ 
    int x; 
    while(true){ 
        if(!(cin>>x)){ 
            cin.clear(); 
            cin.ignore(numeric_limits<streamsize>::max(), '\n'); 
            cout<<"Invalid input. Enter a number: "; 
            continue; 
        } 
        cin.ignore(numeric_limits<streamsize>::max(), '\n'); 
        if(x<minv||x>maxv) 
            cout<<"Enter value between "<<minv<<" and "<<maxv<<": "; 
        else 
            return x; 
    } 
}

void pressAnyKey(){ 
    cout<<"\nPress Enter to continue..."; 
    cin.ignore(numeric_limits<streamsize>::max(), '\n'); 
}

// ----------------- SQL SCHEMA -----------------
const char* SCHEMA_SQL = R"SQL(
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT UNIQUE NOT NULL,
  password TEXT NOT NULL,
  role INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS disaster_zones (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  location TEXT NOT NULL,
  severity TEXT NOT NULL,
  people_affected INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS resources (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  quantity INTEGER NOT NULL,
  type INTEGER NOT NULL,
  zone_id INTEGER,
  FOREIGN KEY(zone_id) REFERENCES disaster_zones(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS volunteers (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  contact TEXT NOT NULL,
  available INTEGER NOT NULL,
  assigned_zone INTEGER,
  FOREIGN KEY(assigned_zone) REFERENCES disaster_zones(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS requests (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  requester TEXT NOT NULL,
  resource_type INTEGER NOT NULL,
  quantity INTEGER NOT NULL,
  zone_id INTEGER,
  fulfilled INTEGER NOT NULL DEFAULT 0,
  FOREIGN KEY(zone_id) REFERENCES disaster_zones(id) ON DELETE SET NULL
);
)SQL";

// Also write database.sql file for user's convenience
void write_schema_file(){
    ofstream f("database.sql");
    if(!f) return;
    f<<SCHEMA_SQL;
    f.close();
}

// ----------------- SQLITE HELPERS -----------------
int exec_sql(sqlite3* db, const char* sql){
    char* err = nullptr;
    int rc = sqlite3_exec(db, sql, 0, 0, &err);
    if(rc != SQLITE_OK){ cerr<<"SQL error: "<<(err?err:"(null)")<<"\n"; sqlite3_free(err); }
    return rc;
}

bool initialize_db(sqlite3* db){
    // enable foreign keys
    exec_sql(db, "PRAGMA foreign_keys = ON;");
    int rc = exec_sql(db, SCHEMA_SQL);
    return rc == SQLITE_OK;
}

// ----------------- CRUD: Users -----------------
int create_user(sqlite3* db, const string& username, const string& password, Role role){
    const char* sql = "INSERT INTO users (username, password, role) VALUES (?, ?, ?);";
    sqlite3_stmt* stmt = nullptr;
    if(sqlite3_prepare_v2(db, sql, -1, &stmt, nullptr) != SQLITE_OK) { cerr<<"prepare failed\n"; return -1; }
    sqlite3_bind_text(stmt, 1, username.c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_text(stmt, 2, password.c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_int(stmt, 3, static_cast<int>(role));
    int rc = sqlite3_step(stmt);
    if(rc != SQLITE_DONE){ cerr<<"insert user failed: "<<sqlite3_errmsg(db)<<"\n"; sqlite3_finalize(stmt); return -1; }
    sqlite3_finalize(stmt);
    return (int)sqlite3_last_insert_rowid(db);
}

bool get_user_by_username(sqlite3* db, const string& username, int& out_id, string& out_password, Role& out_role){
    const char* sql = "SELECT id, password, role FROM users WHERE username = ?;";
    sqlite3_stmt* stmt = nullptr;
    if(sqlite3_prepare_v2(db, sql, -1, &stmt, nullptr) != SQLITE_OK) return false;
    sqlite3_bind_text(stmt, 1, username.c_str(), -1, SQLITE_TRANSIENT);
    int rc = sqlite3_step(stmt);
    if(rc == SQLITE_ROW){
        out_id = sqlite3_column_int(stmt, 0);
        out_password = (const char*)sqlite3_column_text(stmt, 1);
        out_role = static_cast<Role>(sqlite3_column_int(stmt, 2));
        sqlite3_finalize(stmt);
        return true;
    }
    sqlite3_finalize(stmt);
    return false;
}


bool update_user_password(sqlite3* db, int user_id, const string& new_password){
    const char* sql = "UPDATE users SET password = ? WHERE id = ?;";
    sqlite3_stmt* stmt = nullptr;
    if(sqlite3_prepare_v2(db, sql, -1, &stmt, nullptr) != SQLITE_OK) return false;
    sqlite3_bind_text(stmt, 1, new_password.c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_int(stmt, 2, user_id);
    int rc = sqlite3_step(stmt);
    sqlite3_finalize(stmt);
    return rc == SQLITE_DONE;
}

bool delete_user(sqlite3* db, int user_id){
    const char* sql = "DELETE FROM users WHERE id = ?;";
    sqlite3_stmt* stmt = nullptr;
    if(sqlite3_prepare_v2(db, sql, -1, &stmt, nullptr) != SQLITE_OK) return false;
    sqlite3_bind_int(stmt, 1, user_id);
    int rc = sqlite3_step(stmt);
    sqlite3_finalize(stmt);
    return rc == SQLITE_DONE;
}


// ----------------- CRUD: Disaster Zones -----------------
int create_zone(sqlite3* db, const string& location, const string& severity, int people_affected){
    const char* sql = "INSERT INTO disaster_zones (location, severity, people_affected) VALUES (?, ?, ?);";
    sqlite3_stmt* stmt = nullptr;
    sqlite3_prepare_v2(db, sql, -1, &stmt, nullptr);
    sqlite3_bind_text(stmt, 1, location.c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_text(stmt, 2, severity.c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_int(stmt, 3, people_affected);
    int rc = sqlite3_step(stmt);
    sqlite3_finalize(stmt);
    if(rc != SQLITE_DONE) return -1;
    return (int)sqlite3_last_insert_rowid(db);
}

bool update_zone(sqlite3* db, int id, const string& location, const string& severity, int people_affected){
    const char* sql = "UPDATE disaster_zones SET location = ?, severity = ?, people_affected = ? WHERE id = ?;";
    sqlite3_stmt* stmt=nullptr; sqlite3_prepare_v2(db, sql, -1, &stmt, nullptr);
    sqlite3_bind_text(stmt,1,location.c_str(),-1,SQLITE_TRANSIENT);
    sqlite3_bind_text(stmt,2,severity.c_str(),-1,SQLITE_TRANSIENT);
    sqlite3_bind_int(stmt,3,people_affected);
    sqlite3_bind_int(stmt,4,id);
    int rc = sqlite3_step(stmt);
    sqlite3_finalize(stmt);
    return rc == SQLITE_DONE;
}

bool delete_zone(sqlite3* db, int id){
    const char* sql = "DELETE FROM disaster_zones WHERE id = ?;";
    sqlite3_stmt* stmt=nullptr; sqlite3_prepare_v2(db, sql, -1, &stmt, nullptr);
    sqlite3_bind_int(stmt,1,id);
    int rc = sqlite3_step(stmt);
    sqlite3_finalize(stmt);
    return rc == SQLITE_DONE;
}

vector<tuple<int,string,string,int>> list_zones(sqlite3* db){
    vector<tuple<int,string,string,int>> out;
    const char* sql = "SELECT id, location, severity, people_affected FROM disaster_zones;";
    sqlite3_stmt* stmt=nullptr; if(sqlite3_prepare_v2(db, sql, -1, &stmt, nullptr)==SQLITE_OK){
        while(sqlite3_step(stmt)==SQLITE_ROW){
            int id = sqlite3_column_int(stmt,0);
            string loc = (const char*)sqlite3_column_text(stmt,1);
            string sev = (const char*)sqlite3_column_text(stmt,2);
            int pa = sqlite3_column_int(stmt,3);
            out.emplace_back(id, loc, sev, pa);
        }
    }
    sqlite3_finalize(stmt);
    return out;
}


// ----------------- CRUD: Resources -----------------
int create_resource(sqlite3* db, const string& name, int quantity, ResourceType type, int zone_id){
    const char* sql = "INSERT INTO resources (name, quantity, type, zone_id) VALUES (?, ?, ?, ?);";
    sqlite3_stmt* stmt = nullptr;
    if (sqlite3_prepare_v2(db, sql, -1, &stmt, nullptr) != SQLITE_OK) {
        cerr << "prepare failed: " << sqlite3_errmsg(db) << "\n";
        return -1;
    }
    sqlite3_bind_text(stmt, 1, name.c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_int(stmt, 2, quantity);
    sqlite3_bind_int(stmt, 3, static_cast<int>(type));
    if (zone_id > 0)
        sqlite3_bind_int(stmt, 4, zone_id);
    else
        sqlite3_bind_null(stmt, 4);
    int rc = sqlite3_step(stmt);
    sqlite3_finalize(stmt);
    if (rc != SQLITE_DONE) return -1;
    return (int)sqlite3_last_insert_rowid(db);
}

bool update_resource(sqlite3* db, int id, const string& name, int quantity, ResourceType type, int zone_id){
    const char* sql = "UPDATE resources SET name = ?, quantity = ?, type = ?, zone_id = ? WHERE id = ?;";
    sqlite3_stmt* stmt = nullptr;
    if (sqlite3_prepare_v2(db, sql, -1, &stmt, nullptr) != SQLITE_OK) {
        cerr << "prepare failed: " << sqlite3_errmsg(db) << "\n";
        return false;
    }
    sqlite3_bind_text(stmt, 1, name.c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_int(stmt, 2, quantity);
    sqlite3_bind_int(stmt, 3, static_cast<int>(type));
    if (zone_id > 0)
        sqlite3_bind_int(stmt, 4, zone_id);
    else
        sqlite3_bind_null(stmt, 4);
    sqlite3_bind_int(stmt, 5, id);
    int rc = sqlite3_step(stmt);
    sqlite3_finalize(stmt);
    return rc == SQLITE_DONE;
}

bool delete_resource(sqlite3* db, int id){
    const char* sql = "DELETE FROM resources WHERE id = ?;";
    sqlite3_stmt* stmt = nullptr;
    if (sqlite3_prepare_v2(db, sql, -1, &stmt, nullptr) != SQLITE_OK) return false;
    sqlite3_bind_int(stmt, 1, id);
    int rc = sqlite3_step(stmt);
    sqlite3_finalize(stmt);
    return rc == SQLITE_DONE;
}

vector<tuple<int,string,int,int>> list_resources(sqlite3* db){
    vector<tuple<int,string,int,int>> out; // id, name, qty, type
    const char* sql = "SELECT id, name, quantity, type FROM resources;";
    sqlite3_stmt* stmt = nullptr;
    if (sqlite3_prepare_v2(db, sql, -1, &stmt, nullptr) == SQLITE_OK){
        while (sqlite3_step(stmt) == SQLITE_ROW){
            int id = sqlite3_column_int(stmt, 0);
            string name = (const char*)sqlite3_column_text(stmt, 1);
            int q = sqlite3_column_int(stmt, 2);
            int t = sqlite3_column_int(stmt, 3);
            out.emplace_back(id, name, q, t);
        }
    }
    sqlite3_finalize(stmt);
    return out;
}
// ----------------- CRUD: Volunteers -----------------
int create_volunteer(sqlite3* db, const string& name, const string& contact, bool available, int assigned_zone){
    const char* sql = "INSERT INTO volunteers (name, contact, available, assigned_zone) VALUES (?, ?, ?, ?);";
    sqlite3_stmt* stmt = nullptr;
    sqlite3_prepare_v2(db, sql, -1, &stmt, nullptr);
    sqlite3_bind_text(stmt, 1, name.c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_text(stmt, 2, contact.c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_int(stmt, 3, available ? 1 : 0);
    if (assigned_zone > 0)
        sqlite3_bind_int(stmt, 4, assigned_zone);
    else
        sqlite3_bind_null(stmt, 4);
    int rc = sqlite3_step(stmt);
    sqlite3_finalize(stmt);
    if (rc != SQLITE_DONE) return -1;
    return (int)sqlite3_last_insert_rowid(db);
}

bool update_volunteer(sqlite3* db, int id, const string& name, const string& contact, bool available, int assigned_zone){
    const char* sql = "UPDATE volunteers SET name = ?, contact = ?, available = ?, assigned_zone = ? WHERE id = ?;";
    sqlite3_stmt* stmt = nullptr;
    sqlite3_prepare_v2(db, sql, -1, &stmt, nullptr);
    sqlite3_bind_text(stmt, 1, name.c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_text(stmt, 2, contact.c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_int(stmt, 3, available ? 1 : 0);
    if (assigned_zone > 0)
        sqlite3_bind_int(stmt, 4, assigned_zone);
    else
        sqlite3_bind_null(stmt, 4);
    sqlite3_bind_int(stmt, 5, id);
    int rc = sqlite3_step(stmt);
    sqlite3_finalize(stmt);
    return rc == SQLITE_DONE;
}

bool delete_volunteer(sqlite3* db, int id){
    const char* sql = "DELETE FROM volunteers WHERE id = ?;";
    sqlite3_stmt* stmt = nullptr;
    int rc = sqlite3_prepare_v2(db, sql, -1, &stmt, nullptr);
    if(rc != SQLITE_OK){ if(stmt) sqlite3_finalize(stmt); return false; }
    sqlite3_bind_int(stmt, 1, id);
    rc = sqlite3_step(stmt);
    sqlite3_finalize(stmt);
    return rc == SQLITE_DONE;
}

vector<tuple<int,string,string,bool,int>> list_vols(sqlite3* db){
    vector<tuple<int,string,string,bool,int>> out;
    const char* sql = "SELECT id, name, contact, available, assigned_zone FROM volunteers;";
    sqlite3_stmt* stmt = nullptr;
    if (sqlite3_prepare_v2(db, sql, -1, &stmt, nullptr) == SQLITE_OK){
        while (sqlite3_step(stmt) == SQLITE_ROW){
            int id = sqlite3_column_int(stmt, 0);
            const unsigned char* name_txt = sqlite3_column_text(stmt, 1);
            const unsigned char* contact_txt = sqlite3_column_text(stmt, 2);
            string name = name_txt ? reinterpret_cast<const char*>(name_txt) : string();
            string contact = contact_txt ? reinterpret_cast<const char*>(contact_txt) : string();
            bool av = sqlite3_column_int(stmt, 3) != 0;
            int az = sqlite3_column_type(stmt, 4) == SQLITE_NULL ? 0 : sqlite3_column_int(stmt, 4);
            out.emplace_back(id, name, contact, av, az);
        }
    }
    if(stmt) sqlite3_finalize(stmt);
    return out;
}
// ----------------- CRUD: Requests -----------------
int create_request(sqlite3* db, const string& requester, ResourceType resource_type, int quantity, int zone_id){
    const char* sql = "INSERT INTO requests (requester, resource_type, quantity, zone_id, fulfilled) VALUES (?, ?, ?, ?, 0);";
    sqlite3_stmt* stmt = nullptr;
    int rc = sqlite3_prepare_v2(db, sql, -1, &stmt, nullptr);
    if(rc != SQLITE_OK){ if(stmt) sqlite3_finalize(stmt); cerr<<"prepare failed: "<<sqlite3_errmsg(db)<<"\n"; return -1; }
    sqlite3_bind_text(stmt, 1, requester.c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_int(stmt, 2, static_cast<int>(resource_type));
    sqlite3_bind_int(stmt, 3, quantity);
    if (zone_id > 0)
        sqlite3_bind_int(stmt, 4, zone_id);
    else
        sqlite3_bind_null(stmt, 4);
    rc = sqlite3_step(stmt);
    sqlite3_finalize(stmt);
    if (rc != SQLITE_DONE) return -1;
    return (int)sqlite3_last_insert_rowid(db);
}

bool fulfill_request(sqlite3* db, int request_id){
    const char* sql = "UPDATE requests SET fulfilled = 1 WHERE id = ?;";
    sqlite3_stmt* stmt = nullptr;
    int rc = sqlite3_prepare_v2(db, sql, -1, &stmt, nullptr);
    if(rc != SQLITE_OK){ if(stmt) sqlite3_finalize(stmt); return false; }
    sqlite3_bind_int(stmt, 1, request_id);
    rc = sqlite3_step(stmt);
    sqlite3_finalize(stmt);
    return rc == SQLITE_DONE;
}

vector<tuple<int,string,int,int,bool>> list_requests(sqlite3* db){
    vector<tuple<int,string,int,int,bool>> out;
    const char* sql = "SELECT id, requester, resource_type, quantity, fulfilled FROM requests;";
    sqlite3_stmt* stmt = nullptr;
    if (sqlite3_prepare_v2(db, sql, -1, &stmt, nullptr) == SQLITE_OK){
        while (sqlite3_step(stmt) == SQLITE_ROW){
            int id = sqlite3_column_int(stmt, 0);
            const unsigned char* req_txt = sqlite3_column_text(stmt, 1);
            string req = req_txt ? reinterpret_cast<const char*>(req_txt) : string();
            int rt = sqlite3_column_int(stmt, 2);
            int q = sqlite3_column_int(stmt, 3);
            bool f = sqlite3_column_int(stmt, 4) != 0;
            out.emplace_back(id, req, rt, q, f);
        }
    }
    sqlite3_finalize(stmt);
    return out;
}

// ----------------- SIMPLE DEMO UI USING DB -----------------
void show_resources(sqlite3* db){
    auto rows = list_resources(db);
    cout<<left<<setw(5)<<"ID"<<setw(25)<<"Name"<<setw(8)<<"Qty"<<setw(10)<<"Type"<<"\n";
    for(auto &r: rows){
        cout<<setw(5)<<get<0>(r)
            <<setw(25)<<get<1>(r)
            <<setw(8)<<get<2>(r)
            <<setw(10)<<res_to_string(static_cast<ResourceType>(get<3>(r)))<<"\n";
    }
    // ensure a trailing newline so the "Press Enter to continue..." prompt starts on a new line
    cout << '\n';
}

void add_resource_ui(sqlite3* db){
    cout<<"Resource name: "; string name; getline(cin >> ws, name);
    cout<<"Quantity: "; int qty = getIntInRange(0,1000000);
    cout<<"Type (0-FOOD 1-WATER 2-SHELTER 3-MEDICAL 4-OTHER): "; int t = getIntInRange(0,4);
    cout<<"Zone ID (0 for none): "; int zid = getIntInRange(0,1000000);
    int id = create_resource(db,name,qty,static_cast<ResourceType>(t), zid>0?zid:0);
    if(id>0) cout<<"Added resource with ID: "<<id<<"\n"; else cout<<"Failed to add resource\n";
    pressAnyKey();
}

void show_volunteers(sqlite3* db){
    auto v = list_vols(db);
    cout<<left<<setw(5)<<"ID"<<setw(20)<<"Name"<<setw(15)<<"Contact"<<setw(10)<<"Avail"<<setw(10)<<"ZoneID"<<"\n";
    for(auto &x: v){
        cout<<setw(5)<<get<0>(x)
            <<setw(20)<<get<1>(x)
            <<setw(15)<<get<2>(x)
            <<setw(10)<<(get<3>(x)?"Yes":"No")
            <<setw(10)<<get<4>(x)<<"\n";
    }
}

void add_vol_ui(sqlite3* db){
    cout<<"Volunteer name: "; string name; getline(cin,name);
    cout<<"Contact: "; string c; getline(cin,c);
    cout<<"Available? (1-yes 0-no): "; int av = getIntInRange(0,1);
    cout<<"Assigned zone id (0 for none): "; int zid = getIntInRange(0,1000000);
    int id = create_volunteer(db,name,c,av==1,zid>0?zid:0);
    if(id>0) cout<<"Added volunteer ID: "<<id<<"\n"; else cout<<"Failed to add volunteer\n";
    pressAnyKey();
}

void show_requests_ui(sqlite3* db){
    auto r = list_requests(db);
    cout<<left<<setw(5)<<"ID"<<setw(25)<<"Requester"<<setw(10)<<"Type"<<setw(8)<<"Qty"<<setw(10)<<"Fulfilled"<<"\n";
    for(auto &x: r){
        cout<<setw(5)<<get<0>(x)
            <<setw(25)<<get<1>(x)
            <<setw(10)<<res_to_string(static_cast<ResourceType>(get<2>(x)))
            <<setw(8)<<get<3>(x)
            <<setw(10)<<(get<4>(x)?"Yes":"No")<<"\n";
    }
}

void add_request_ui(sqlite3* db){
    cout<<"Requester name: "; string r; getline(cin,r);
    cout<<"Resource type (0-4): "; int t = getIntInRange(0,4);
    cout<<"Quantity: "; int q = getIntInRange(1,1000000);
    cout<<"Zone id (0 none): "; int zid = getIntInRange(0,1000000);
    int id = create_request(db,r,static_cast<ResourceType>(t),q,zid>0?zid:0);
    if(id>0) cout<<"Created request id: "<<id<<"\n"; else cout<<"Failed to create request\n";
    pressAnyKey();
}

// ----------------- AUTH UI -----------------
bool login_ui(sqlite3* db, int &out_user_id, Role &out_role){
    cout<<"Username: "; string u; getline(cin,u);
    cout<<"Password: "; string p; getline(cin,p);
    int id; string pw; Role r;
    if(get_user_by_username(db,u,id,pw,r)){
        if(pw==p){
            out_user_id=id; out_role=r; return true;
        } else {
            cout<<"Invalid password.\n"; pressAnyKey(); return false;
        }
    } else {
        cout<<"User not found.\n"; pressAnyKey(); return false;
    }
}

// ----------------- MAIN MENU -----------------
void main_menu(sqlite3* db){
    while(true){
        system("clear || cls");
        cout<<"Flood Relief Management (SQLite-backed)\n";
        cout<<"1. Login\n2. Register\n3. Exit\n";
        int c = getIntInRange(1,3);
        if(c==1){
            int uid; Role role;
            if(login_ui(db, uid, role)){
                // simple post-login menu
                bool session=true;
                while(session){
                    system("clear || cls");
                    cout<<"Logged in (User ID: "<<uid<<") Role: "<<role_to_string(role)<<"\n";
                    cout<<"1. View Resources\n2. Add Resource\n3. View Volunteers\n4. Add Volunteer\n5. View Requests\n6. Add Request\n7. Logout\n";
                    int ch = getIntInRange(1,7);
                    switch(ch){
                        case 1: show_resources(db); pressAnyKey(); break;
                        case 2: add_resource_ui(db); break;
                        case 3: show_volunteers(db); pressAnyKey(); break;
                        case 4: add_vol_ui(db); break;
                        case 5: show_requests_ui(db); pressAnyKey(); break;
                        case 6: add_request_ui(db); break;
                        case 7: session=false; break;
                    }
                }
            }
        } else if(c==2){
            cout<<"Register username: "; string un; getline(cin,un);
            cout<<"Password: "; string pw; getline(cin,pw);
            cout<<"Role (0-admin/1-coord/2-vol): "; int rr = getIntInRange(0,2);
            int id = create_user(db,un,pw, static_cast<Role>(rr));
            if(id>0) cout<<"Registered id: "<<id<<"\n"; else cout<<"Failed to register (maybe username exists)\n";
            pressAnyKey();
        } else {
            cout<<"Exiting...\n";
            break;
        }
    }
}

int main(){
    write_schema_file();
    sqlite3* db = nullptr;
    int rc = sqlite3_open(DB_FILENAME, &db);
    if(rc){ cerr<<"Cannot open DB: "<<sqlite3_errmsg(db)<<"\n"; return 1; }
    if(!initialize_db(db)){ cerr<<"Failed to init schema\n"; sqlite3_close(db); return 1; }

    // seed an admin user if none exists
    int uid; string pw; Role r;
    if(!get_user_by_username(db, "admin", uid, pw, r)){
        create_user(db, "admin", "admin123", Role::ADMIN);
    }

    main_menu(db);

    sqlite3_close(db);
    return 0;
}

/*
Windows 10 step-by-step setup (recap):
1. Install MSYS2 (https://www.msys2.org/) and follow the installer instructions.
2. Open MSYS2 MinGW 64-bit shell (from Start Menu).
3. Update packages: pacman -Syu (may need to close and reopen terminal)
4. Install toolchain and sqlite: pacman -S mingw-w64-x86_64-gcc mingw-w64-x86_64-sqlite3
5. Save this file as main.cpp in your working folder.
6. Compile: g++ main.cpp -lsqlite3 -o flood_app.exe
7. Run: ./flood_app.exe

Linux (Ubuntu/Debian):
1. sudo apt update && sudo apt install build-essential libsqlite3-dev
2. g++ main.cpp -lsqlite3 -o flood_app
3. ./flood_app
*/
