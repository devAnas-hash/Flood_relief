
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT UNIQUE NOT NULL,
  password TEXT NOT NULL,
  role INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS disaster_zones (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  location TEXT NOT NULL,
  severity TEXT NOT NULL,
  people_affected INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS resources (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  quantity INTEGER NOT NULL,
  type INTEGER NOT NULL,
  zone_id INTEGER,
  FOREIGN KEY(zone_id) REFERENCES disaster_zones(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS volunteers (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  contact TEXT NOT NULL,
  available INTEGER NOT NULL,
  assigned_zone INTEGER,
  FOREIGN KEY(assigned_zone) REFERENCES disaster_zones(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS requests (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  requester TEXT NOT NULL,
  resource_type INTEGER NOT NULL,
  quantity INTEGER NOT NULL,
  zone_id INTEGER,
  fulfilled INTEGER NOT NULL DEFAULT 0,
  FOREIGN KEY(zone_id) REFERENCES disaster_zones(id) ON DELETE SET NULL
);
